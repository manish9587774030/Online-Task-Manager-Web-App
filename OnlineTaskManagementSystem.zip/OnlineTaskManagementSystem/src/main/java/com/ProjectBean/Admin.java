package com.ProjectBean;

import javax.validation.constraints.Size;

public class Admin {

	 @Size(min=1,message="required")  
	private String username;
	
	 @Size(min=1,message="required")  
	private String password;

	public Admin() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	 
	 
	 
	
}
