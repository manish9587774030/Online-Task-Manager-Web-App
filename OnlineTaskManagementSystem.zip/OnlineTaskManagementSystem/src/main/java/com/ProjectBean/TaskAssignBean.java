package com.ProjectBean;

import java.sql.Date;



public class TaskAssignBean {

	private int id;
	private int usercode;
	private Date currentdate;
	private String module;
	private String task;
	private String description;
	private String assignedto;
	private String status;
	private String remarks;
	private Date enddate;
	private char ACTIVE_YN;
	
	public TaskAssignBean(int id, int usercode, Date currentdate, String module, String task, String description,
			String assignedto, String status, String remarks, Date enddate, char aCTIVE_YN, String dEVELOPER_ID) {
		super();
		this.id = id;
		this.usercode = usercode;
		this.currentdate = currentdate;
		this.module = module;
		this.task = task;
		this.description = description;
		this.assignedto = assignedto;
		this.status = status;
		this.remarks = remarks;
		this.enddate = enddate;
		ACTIVE_YN = aCTIVE_YN;
		DEVELOPER_ID = dEVELOPER_ID;
	}
	public char getACTIVE_YN() {
		return ACTIVE_YN;
	}
	public void setACTIVE_YN(char aCTIVE_YN) {
		ACTIVE_YN = aCTIVE_YN;
	}
	public TaskAssignBean(int id, int usercode, Date currentdate, String module, String task, String description,
			String assignedto, String status, String remarks, Date enddate, String dEVELOPER_ID) {
		super();
		this.id = id;
		this.usercode = usercode;
		this.currentdate = currentdate;
		this.module = module;
		this.task = task;
		this.description = description;
		this.assignedto = assignedto;
		this.status = status;
		this.remarks = remarks;
		this.enddate = enddate;
		DEVELOPER_ID = dEVELOPER_ID;
	}
	public Date getEnddate() {
		return enddate;
	}
	public void setEnddate(Date enddate) {
		this.enddate = enddate;
	}
	private String DEVELOPER_ID;
	
	
	public TaskAssignBean(int id, int usercode, Date currentdate, String module, String task, String description,
			String assignedto, String status, String remarks, String dEVELOPER_ID) {
		super();
		this.id = id;
		this.usercode = usercode;
		this.currentdate = currentdate;
		this.module = module;
		this.task = task;
		this.description = description;
		this.assignedto = assignedto;
		this.status = status;
		this.remarks = remarks;
		DEVELOPER_ID = dEVELOPER_ID;
	}
	public String getDEVELOPER_ID() {
		return DEVELOPER_ID;
	}
	public void setDEVELOPER_ID(String dEVELOPER_ID) {
		DEVELOPER_ID = dEVELOPER_ID;
	}
	public TaskAssignBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public TaskAssignBean(Date currentdate, String module, String task, String description, String assignedto,
			String status, String remarks) {
		super();
		this.currentdate = currentdate;
		this.module = module;
		this.task = task;
		this.description = description;
		this.assignedto = assignedto;
		this.status = status;
		this.remarks = remarks;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getUsercode() {
		return usercode;
	}
	public void setUsercode(int usercode) {
		this.usercode = usercode;
	}
	public Date getCurrentdate() {
		return currentdate;
	}
	public void setCurrentdate(Date currentdate) {
		this.currentdate = currentdate;
	}
	public String getModule() {
		return module;
	}
	public void setModule(String module) {
		this.module = module;
	}
	public String getTask() {
		return task;
	}
	public void setTask(String task) {
		this.task = task;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getAssignedto() {
		return assignedto;
	}
	public void setAssignedto(String assignedto) {
		this.assignedto = assignedto;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public TaskAssignBean(int id, Date currentdate, String module, String task, String description,
			String assignedto, String status, String remarks) {
		super();
		this.id = id;
		this.currentdate = currentdate;
		this.module = module;
		this.task = task;
		this.description = description;
		this.assignedto = assignedto;
		this.status = status;
		this.remarks = remarks;
	}
	public TaskAssignBean(int id, int usercode, Date currentdate, String module, String task, String description,
			String assignedto, String status, String remarks) {
		super();
		this.id = id;
		this.usercode = usercode;
		this.currentdate = currentdate;
		this.module = module;
		this.task = task;
		this.description = description;
		this.assignedto = assignedto;
		this.status = status;
		this.remarks = remarks;
	}
	public int getid() {
		return id;
	}
	public void setid(int id) {
		this.id =id;
	}
	@Override
	public String toString() {
		return "TaskAssignBean [id=" + id + ", usercode=" + usercode + ", currentdate=" + currentdate + ", module="
				+ module + ", task=" + task + ", description=" + description + ", assignedto=" + assignedto
				+ ", status=" + status + ", remarks=" + remarks + ", enddate=" + enddate + ", ACTIVE_YN=" + ACTIVE_YN
				+ ", DEVELOPER_ID=" + DEVELOPER_ID + "]";
	}
	
	
	
	
}
