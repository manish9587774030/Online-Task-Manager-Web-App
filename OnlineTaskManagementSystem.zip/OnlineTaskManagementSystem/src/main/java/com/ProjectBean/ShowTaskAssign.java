package com.ProjectBean;

import java.sql.Date;

public class ShowTaskAssign {

	private int id;
	private Date currentdate;
	private Date enddate;
	private String module;
	private String task;
	private String description;
	private String assignedto;
	private String status;
	private String remarks;

	public ShowTaskAssign() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ShowTaskAssign(int id, Date currentdate, Date enddate, String module, String task, String description,
			String assignedto, String status, String remarks) {
		super();
		this.id = id;
		this.currentdate = currentdate;
		this.enddate = enddate;
		this.module = module;
		this.task = task;
		this.description = description;
		this.assignedto = assignedto;
		this.status = status;
		this.remarks = remarks;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Date getCurrentdate() {
		return currentdate;
	}

	public void setCurrentdate(Date currentdate) {
		this.currentdate = currentdate;
	}

	public Date getenddate() {
		return enddate;
	}

	public void setenddate(Date enddate) {
		this.enddate = enddate;
	}

	public String getModule() {
		return module;
	}

	public void setModule(String module) {
		this.module = module;
	}

	public String getTask() {
		return task;
	}

	public void setTask(String task) {
		this.task = task;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getAssignedto() {
		return assignedto;
	}

	public void setAssignedto(String assignedto) {
		this.assignedto = assignedto;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

}
