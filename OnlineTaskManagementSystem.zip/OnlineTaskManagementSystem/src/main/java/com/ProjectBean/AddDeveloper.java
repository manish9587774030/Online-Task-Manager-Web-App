package com.ProjectBean;

import javax.validation.constraints.NotNull;

public class AddDeveloper {
	
	@NotNull
	private String usercode;
	@NotNull
	private String userid;
	@NotNull
	private String name;
	@NotNull
	private String email;
	@NotNull
	private String password;
	@NotNull
	private String mobilenumber;
	@NotNull
	private String designation;
	
	private char Active_YN;
	
	@Override
	public String toString() {
		return "AddDeveloper [usercode=" + usercode + ", userid=" + userid + ", name=" + name + ", email=" + email
				+ ", password=" + password + ", mobilenumber=" + mobilenumber + ", designation=" + designation
				+ ", Active_YN=" + Active_YN + "]";
	}
	public AddDeveloper(String usercode, String userid, String name, String email, String password, String mobilenumber,
			String designation, char active_YN) {
		super();
		this.usercode = usercode;
		this.userid = userid;
		this.name = name;
		this.email = email;
		this.password = password;
		this.mobilenumber = mobilenumber;
		this.designation = designation;
		Active_YN = active_YN;
	}
	public char getActive_YN() {
		return Active_YN;
	}
	public void setActive_YN(char Y) {
		Active_YN = Y;
	}
	public AddDeveloper() {
		super();
		// TODO Auto-generated constructor stub
	}
	public AddDeveloper(String usercode, String userid, String name, String email, String password, String mobilenumber,
			String designation) {
		super();
		this.usercode = usercode;
		this.userid = userid;
		this.name = name;
		this.email = email;
		this.password = password;
		this.mobilenumber = mobilenumber;
		this.designation = designation;
	}
	public AddDeveloper(String usercode, String name, String email, String password, String mobilenumber,
			String designation) {
		super();
		this.usercode = usercode;
		this.name = name;
		this.email = email;
		this.password = password;
		this.mobilenumber = mobilenumber;
		this.designation = designation;
	}
	public String getUsercode() {
		return usercode;
	}
	public void setUsercode(String usercode) {
		this.usercode = usercode;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getMobilenumber() {
		return mobilenumber;
	}
	public void setMobilenumber(String mobilenumber) {
		this.mobilenumber = mobilenumber;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	
	
	

}
