package com.projectDao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.ProjectBean.ShowTaskAssign;


public class ShowTaskCompletedImpl implements ShowTaskCompletedDao {

	JdbcTemplate template3;

	public JdbcTemplate getTemplate3() {
		return template3;
	}

	public void setTemplate3(JdbcTemplate template3) {
		this.template3 = template3;
	}

	public List<ShowTaskAssign> getAllTaskCompleted() {
		 {

			return template3.query("select id,currentdate,module,task,description,A.name,status,remarks,enddate\r\n" + 
					"from TASK_DEVELOPERCOMPLETED T,ADD_DEVELOPER A\r\n" + 
					"where \r\n" + 
					"T.ASSIGNEDTO = A.USERCODE", new RowMapper<ShowTaskAssign>() {
				public ShowTaskAssign mapRow(ResultSet rs, int rownumber) throws SQLException {

					ShowTaskAssign t = new ShowTaskAssign();
				    t.setId(rs.getInt(1));
					t.setCurrentdate(rs.getDate(2));
					t.setModule(rs.getString(3));
					t.setTask(rs.getString(4));
					t.setDescription(rs.getString(5));
					t.setAssignedto(rs.getString(6));
					t.setStatus(rs.getString(7));
					t.setRemarks(rs.getString(8));
					t.setenddate(rs.getDate(9));

					return t;

				}
			});

		 }
	}

	public List<ShowTaskAssign> getAllTaskPending() {
	
		return template3.query("select * from TASK_DEVELOPERCOMPLETED where status like 'Pending' ", new RowMapper<ShowTaskAssign>() {
			public ShowTaskAssign mapRow(ResultSet rs, int rownumber) throws SQLException {

				ShowTaskAssign t = new ShowTaskAssign();
			    t.setId(rs.getInt(1));
				t.setCurrentdate(rs.getDate(2));
				t.setModule(rs.getString(3));
				t.setTask(rs.getString(4));
				t.setDescription(rs.getString(5));
				t.setAssignedto(rs.getString(6));
				t.setStatus(rs.getString(7));
				t.setRemarks(rs.getString(8));
				t.setenddate(rs.getDate(9));

				return t;

			}
		});
	}

	public List<ShowTaskAssign> getAllTaskCompletedList() {
		return template3.query("select id,currentdate,module,task,description,A.name,status,remarks,enddate\r\n" + 
				"from TASK_DEVELOPERCOMPLETED T,ADD_DEVELOPER A\r\n" + 
				"where \r\n" + 
				"T.ASSIGNEDTO = A.USERCODE ", new RowMapper<ShowTaskAssign>() {
			public ShowTaskAssign mapRow(ResultSet rs, int rownumber) throws SQLException {

				ShowTaskAssign t = new ShowTaskAssign();
			    t.setId(rs.getInt(1));
				t.setCurrentdate(rs.getDate(2));
				t.setModule(rs.getString(3));
				t.setTask(rs.getString(4));
				t.setDescription(rs.getString(5));
				t.setAssignedto(rs.getString(6));
				t.setStatus(rs.getString(7));
				t.setRemarks(rs.getString(8));
				t.setenddate(rs.getDate(9));

				return t;

			}
		});

	}

	public List<ShowTaskAssign> getAllTaskInProcessList() {
		return template3.query("select * from TASK_DEVELOPERCOMPLETED where status like 'In-Process' ", new RowMapper<ShowTaskAssign>() {
			public ShowTaskAssign mapRow(ResultSet rs, int rownumber) throws SQLException {

				ShowTaskAssign t = new ShowTaskAssign();
			    t.setId(rs.getInt(1));
				t.setCurrentdate(rs.getDate(2));
				t.setModule(rs.getString(3));
				t.setTask(rs.getString(4));
				t.setDescription(rs.getString(5));
				t.setAssignedto(rs.getString(6));
				t.setStatus(rs.getString(7));
				t.setRemarks(rs.getString(8));
				t.setenddate(rs.getDate(9));

				return t;

			}
		});
	}
}