package com.projectDao;

import java.util.List;

import com.ProjectBean.ShowTaskAssign;


public interface ShowTaskCompletedDao {
	
	   List<ShowTaskAssign>getAllTaskCompleted();
	   
	   List<ShowTaskAssign>getAllTaskPending();

	   List<ShowTaskAssign>getAllTaskCompletedList();
	   
	   List<ShowTaskAssign>getAllTaskInProcessList();
	   
}
