package com.projectDao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;

import com.ProjectBean.AddDeveloper;
import com.ProjectBean.TaskAssignBean;

public class TaskAssignImpl implements TaskAssignDao {

	JdbcTemplate template1;

	public JdbcTemplate getTemplate1() {
		return template1;
	}

	public void setTemplate1(JdbcTemplate template1) {
		this.template1 = template1;
	}

		
	public Boolean saveEmployeeByPreparedStatement(final TaskAssignBean bean) {
		String query = "insert into TASK_ASSIGN_DEVELOPER(id,currentdate,module,task,description,assignedto,status,remarks,ACTIVE_YN)values(?,?,?,?,?,?,?,?,?)";
		return template1.execute(query, new PreparedStatementCallback<Boolean>() {
			public Boolean doInPreparedStatement(PreparedStatement ps) throws SQLException, DataAccessException {

				ps.setInt(1, bean.getId());
				ps.setDate(2, bean.getCurrentdate());
				ps.setString(3, bean.getModule());
				ps.setString(4, bean.getTask());
				ps.setString(5, bean.getDescription());
				ps.setString(6, bean.getAssignedto());
				ps.setString(7, bean.getStatus());
				ps.setString(8, bean.getRemarks());
				ps.setString(9,String.valueOf(bean.getACTIVE_YN()));
               
				return ps.execute();

			}
		});
	}

	public List<TaskAssignBean> getAllTask() {

		return template1.query("select id,currentdate,module,task,description,A.name,status,remarks from TASK_ASSIGN_DEVELOPER T,ADD_DEVELOPER A WHERE  T.ASSIGNEDTO=A.USERCODE AND T.ACTIVE_YN='Y'  ",
				new RowMapper<TaskAssignBean>() {
					public TaskAssignBean mapRow(ResultSet rs, int rownumber) throws SQLException {

						TaskAssignBean t = new TaskAssignBean();
						t.setid(rs.getInt(1));
						t.setCurrentdate(rs.getDate(2));
						t.setModule(rs.getString(3));
						t.setTask(rs.getString(4));
						t.setDescription(rs.getString(5));
						t.setAssignedto(rs.getString(6));
						t.setStatus(rs.getString(7));
						t.setRemarks(rs.getString(8));

						return t;

					}
				});

	}

	public TaskAssignBean get(int id) {
		String sql = "SELECT * FROM TASK_ASSIGN_DEVELOPER WHERE id=" + id;
		return template1.queryForObject(sql, BeanPropertyRowMapper.newInstance(TaskAssignBean.class));

	}

	public void saveOrUpdate(TaskAssignBean developer) {
		if (developer.getid() > 0) {
			// update
			String sql = "UPDATE TASK_ASSIGN_DEVELOPER SET module=?, task=?, description=?,assignedto=?,status=?,remarks=? WHERE id=?";
			template1.update(sql, developer.getModule(), developer.getTask(), developer.getDescription(),
					developer.getAssignedto(), developer.getStatus(), developer.getRemarks(), developer.getid());
		} else {
			// insert
			String sql = "insert into TASK_ASSIGN_DEVELOPER(module,task,description,assignedto,status,remarks)values(?,?,?,?,?,?)";
			template1.update(sql, developer.getModule(), developer.getTask(), developer.getDescription(),
					developer.getAssignedto(), developer.getStatus(), developer.getRemarks());
		}

	}

	public void copyRow(TaskAssignBean developer) {

		String sql = "insert into TASK_ASSIGN_DEVELOPER select * from TASK_ASSIGN_DEVELOPER where id="
				+ developer.getid();
		template1.update(sql);

	}

	public void deletetask(int id) {
		{
			String sql = "Update  TASK_ASSIGN_DEVELOPER set ACTIVE_YN='N' WHERE id=?";
			template1.update(sql, id);
		}

	}

	public List<AddDeveloper> getAllName(AddDeveloper developer) {
		return template1.query("SELECT name,usercode FROM ADD_DEVELOPER where ACTIVE_YN='Y'  ",
				new RowMapper<AddDeveloper>() {
					public AddDeveloper mapRow(ResultSet rs, int rownumber) throws SQLException {

						AddDeveloper t = new AddDeveloper();

						t.setName(rs.getString(1));
						t.setUsercode(rs.getString(2));

						return t;

					}
				});
	}

	public Map<String, String> getAllNameBYCode() {
		return template1.query("SELECT usercode,name FROM ADD_DEVELOPER where ACTIVE_YN='Y' ",
				new ResultSetExtractor<Map<String, String>>() {
					public Map<String, String> extractData(ResultSet rs) throws SQLException, DataAccessException {
						Map<String, String> parameters = new HashMap<String, String>();
						while (rs.next()) {
							parameters.put(rs.getString(1), rs.getString(2));

						}
						return parameters;
					}
				});

	}

}