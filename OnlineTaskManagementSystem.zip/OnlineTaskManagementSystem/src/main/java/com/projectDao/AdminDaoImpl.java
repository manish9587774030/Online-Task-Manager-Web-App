package com.projectDao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


import org.springframework.jdbc.core.JdbcTemplate;


public class AdminDaoImpl  {

	static JdbcTemplate template;
	public void setTemplate(JdbcTemplate template)
	{
		this.template=template;
	}
	
	
	public static boolean authenticate(String username,String password){
		boolean status=false;
		try{

			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "system");
			
			PreparedStatement ps=con.prepareStatement("select * from Admin_Login where username=? and password=?");
			ps.setString(1,username);
			ps.setString(2,password);
			ResultSet rs=ps.executeQuery();
			if(rs.next()){
				status=true;
			}
			con.close();
			
		}catch(Exception e){System.out.println(e);}	
		
		return status;
	}


}
