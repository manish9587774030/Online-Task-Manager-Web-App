package com.projectDao;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

import com.ProjectBean.ShowTaskAssign;
import com.ProjectBean.TaskAssignBean;

public class DeveloperSubmitTaskImpl implements developerSubmitTaskDao {

	JdbcTemplate template2;
    
	public JdbcTemplate getTemplate2() {
		return template2;
	}

	public void setTemplate2(JdbcTemplate template2) {
		this.template2 = template2;
	}

	public TaskAssignBean gettask(int id) {
		String sql = "SELECT * FROM TASK_ASSIGN_DEVELOPER WHERE id=" + id;
		return template2.queryForObject(sql, BeanPropertyRowMapper.newInstance(TaskAssignBean.class));

	}

	public int saveorupdate(ShowTaskAssign showtask) {
		
		String query = "select count(id) from TASK_DEVELOPERCOMPLETED WHERE id = "+showtask.getId();
		int checkId = template2.queryForObject(query, Integer.class);	
		
		if(checkId <= 0)
		{
			String sql = "insert into TASK_DEVELOPERCOMPLETED(id,currentdate,module,task,description,assignedto,status,remarks"
					+ ") values ( '" + showtask.getId() + "'  ,TO_DATE('" + showtask.getCurrentdate()
					+ "','YYYY-MM-DD'),'" + showtask.getModule() + "','" + showtask.getTask() + "','"
					+ showtask.getDescription() + "','" + showtask.getAssignedto() + "','" + showtask.getStatus() + "','"
					+ showtask.getRemarks() + "')";
			
			return template2.update(sql);
			
		}else {
		
		  String sql = "UPDATE TASK_DEVELOPERCOMPLETED set currentdate=?,module=?,task=?,description=?,assignedto=?,status=?,remarks=?" ;
		  
		  if(showtask.getStatus().equals("Complete")) {
			  sql += ",enddate=sysdate";
		  }
		  
		  sql += " WHERE id=?";
		  return template2.update(sql, showtask.getCurrentdate(), showtask.getModule(),
		  showtask.getTask(), showtask.getDescription(), showtask.getAssignedto(),
		  showtask.getStatus(), showtask.getRemarks(), showtask.getId());
		 
		}
	}
		
}
