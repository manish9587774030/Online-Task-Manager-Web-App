package com.projectDao;

import java.util.List;

import com.ProjectBean.AddDeveloper;

public interface AddDeveloperDao {
	
	public  int save(AddDeveloper d);
	
	 public  List<AddDeveloper>getAllDeveloper();
	 
	 public void delete(int id);
	 
	 public AddDeveloper get(int id);
	 
	 public void saveorupdate(AddDeveloper developer);
	 
	 public List<AddDeveloper>getAllUserCode();
	 
	
	

}
