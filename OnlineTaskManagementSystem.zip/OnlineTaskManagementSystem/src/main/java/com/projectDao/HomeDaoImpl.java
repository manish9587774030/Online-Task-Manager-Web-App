package com.projectDao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;

import com.ProjectBean.ShowTaskAssign;
import com.ProjectBean.TaskAssignBean;

public class HomeDaoImpl implements HomeDao {

	JdbcTemplate template4;

	public JdbcTemplate getTemplate4() {
		return template4;
	}

	public void setTemplate4(JdbcTemplate template4) {
		this.template4 = template4;
	}

	public List<ShowTaskAssign> viewhome() {

		return template4.query("select currentdate,task,A.name,status,enddate\r\n" + 
				"from TASK_DEVELOPERCOMPLETED T,ADD_DEVELOPER A\r\n" + 
				"where \r\n" + 
				"T.ASSIGNEDTO = A.USERCODE  ", new RowMapper<ShowTaskAssign>() {
			public ShowTaskAssign mapRow(ResultSet rs, int rownumber) throws SQLException {

				ShowTaskAssign t = new ShowTaskAssign();

				t.setCurrentdate(rs.getDate(1));

				t.setTask(rs.getString(2));

				t.setAssignedto(rs.getString(3));
				t.setStatus(rs.getString(4));

				t.setenddate(rs.getDate(5));

				return t;

			}
		});

	}

	public List<ShowTaskAssign> searchtask(ShowTaskAssign show) {

		return template4.query(
				"select * from TASK_DEVELOPERCOMPLETED where 'assignedto' ='" + show.getAssignedto() + "'",
				new RowMapper<ShowTaskAssign>() {
					public ShowTaskAssign mapRow(ResultSet rs, int rownumber) throws SQLException {

						ShowTaskAssign t = new ShowTaskAssign();

						t.setId(rs.getInt(1));
						t.setCurrentdate(rs.getDate(2));
						t.setModule(rs.getString(3));
						t.setTask(rs.getString(4));
						t.setDescription(rs.getString(5));
						t.setAssignedto(rs.getString(6));
						t.setStatus(rs.getString(7));
						t.setRemarks(rs.getString(8));
						t.setenddate(rs.getDate(9));

						return t;

					}
				});

	}

	public List<TaskAssignBean> giventask() {
		return template4.query("select count(status ),STATUS from TASK_DEVELOPERCOMPLETED group by STATUS",
				new RowMapper<TaskAssignBean>() {
					public TaskAssignBean mapRow(ResultSet rs, int rownumber) throws SQLException {

						TaskAssignBean t = new TaskAssignBean();

						t.setTask(rs.getString(1));

						return t;

					}

				});
	}

	public List<ShowTaskAssign> CompletedTask() {

		return template4.query("select count(status) from TASK_DEVELOPERCOMPLETED where status like 'Complete'",
				new RowMapper<ShowTaskAssign>() {
					public ShowTaskAssign mapRow(ResultSet rs, int rownumber) throws SQLException {

						ShowTaskAssign t = new ShowTaskAssign();

						t.setStatus(rs.getString(1));

						return t;

					}

				});
	}

	public List<ShowTaskAssign> PendingTask() {
		return template4.query("select count(status) from TASK_DEVELOPERCOMPLETED where status like 'Pending'",
				new RowMapper<ShowTaskAssign>() {
					public ShowTaskAssign mapRow(ResultSet rs, int rownumber) throws SQLException {

						ShowTaskAssign t = new ShowTaskAssign();

						t.setStatus(rs.getString(1));

						return t;

					}

				});
	}

	

	public Map<String, String> getAllTaskCom() {
		return template4.query("select STATUS,count(*) from TASK_DEVELOPERCOMPLETED group by STATUS",
				new ResultSetExtractor<Map<String, String>>() {
					public Map<String, String> extractData(ResultSet rs) throws SQLException, DataAccessException {
						Map<String, String> parameters = new HashMap<String, String>();
						while(rs.next())
						{
						parameters.put(rs.getString(1), rs.getString(2));	
						
					}
						return parameters;
					}
				});

	}
}