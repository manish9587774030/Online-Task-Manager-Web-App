package com.projectDao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DeveloperLoginImpl  {

	public static boolean authenticate(String usercode, String password) {
		
		boolean status=false;
		try{

			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "system");
			
			PreparedStatement ps=con.prepareStatement("select * from ADD_DEVELOPER where usercode=? and password=?");
			ps.setString(1,usercode);
			ps.setString(2,password);
			ResultSet rs=ps.executeQuery();
			if(rs.next()){
				status=true;
			}
			con.close();
			
		}catch(Exception e){System.out.println(e);}	
		
		return status;
	}
	}
	
	

