package com.projectDao;

import java.util.List;

import com.ProjectBean.ShowTaskAssign;
import com.ProjectBean.TaskAssignBean;

public interface developerSubmitTaskDao {

	public TaskAssignBean gettask(int id);

	public int saveorupdate(ShowTaskAssign showtask);

}
