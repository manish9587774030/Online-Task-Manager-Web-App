package com.projectDao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.ProjectBean.AddDeveloper;

public class AddDeveloperImpl implements AddDeveloperDao {

	JdbcTemplate template;

	public void setTemplate(JdbcTemplate template) {
		this.template = template;

	}

	public int save(AddDeveloper d) {

		
		String sql = "insert into ADD_DEVELOPER(usercode,name,email,password,mobilenumber,designation,ACTIVE_YN) values('"
				+ d.getUsercode() + "','" + d.getName() + "','" + d.getEmail() + "','" + d.getPassword() + "','"
				+ d.getMobilenumber() + "','" + d.getDesignation() + "','"+d.getActive_YN()+"')";

		return template.update(sql);
	}

	public List<AddDeveloper> getAllDeveloper() {

		return template.query("select * from ADD_DEVELOPER where ACTIVE_YN='Y' ", new RowMapper<AddDeveloper>() {
			public AddDeveloper mapRow(ResultSet rs, int rownumber) throws SQLException {
				AddDeveloper d = new AddDeveloper();
				d.setUsercode(rs.getString(1));
				d.setUserid(rs.getString(2));
				d.setName(rs.getString(3));
				d.setEmail(rs.getString(4));
				d.setPassword(rs.getString(5));
				d.setMobilenumber(rs.getString(6));
				d.setDesignation(rs.getString(7));

				return d;

			}																					

		}

		);

	}

	public void delete(int id) {
	
		String sql = "Update ADD_DEVELOPER set ACTIVE_YN='N' where userid=? ";
		template.update(sql,id);
	}

	public AddDeveloper get(int id) {
		String sql = "SELECT * FROM ADD_DEVELOPER WHERE userid=" + id;
		return template.queryForObject(sql, BeanPropertyRowMapper.newInstance(AddDeveloper.class));
	}

	public void saveorupdate(AddDeveloper developer) {
		if (developer.getUserid() != null) {
			// update
			String sql = "UPDATE ADD_DEVELOPER SET name=?, email=?, password=?,mobilenumber=?,designation=? WHERE userid=?";
			template.update(sql, developer.getName(), developer.getEmail(), developer.getPassword(),
					developer.getMobilenumber(), developer.getDesignation(), developer.getUserid());
		} else {
			// insert
			String sql = "INSERT INTO ADD_DEVELOPER (name, email, password, mobilenumber,designation)"
					+ " VALUES (?, ?, ?, ?,?)";
			template.update(sql, developer.getName(), developer.getEmail(), developer.getPassword(),
					developer.getMobilenumber(), developer.getDesignation());
		}

	}

	public List<AddDeveloper> getAllUserCode() {
		return template.query("SELECT DISTINCT USERCODE FROM ADD_DEVELOPER ", new RowMapper<AddDeveloper>() {
			public AddDeveloper mapRow(ResultSet rs, int rownumber) throws SQLException {
				AddDeveloper d = new AddDeveloper();
				d.setUsercode(rs.getString(1));
				return d;

			}

		}

		);

		
		
	}

}
