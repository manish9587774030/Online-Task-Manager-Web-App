package com.projectDao;

import java.sql.Date;
import java.text.ParseException;
import java.util.List;
import java.util.Map;

import com.ProjectBean.AddDeveloper;
import com.ProjectBean.TaskAssignBean;

public interface TaskAssignDao {
	

	public Boolean saveEmployeeByPreparedStatement(final TaskAssignBean bean);
	
	  public  List<TaskAssignBean>getAllTask();
	  
	  public TaskAssignBean get(int id);
	  
	  public  void saveOrUpdate(TaskAssignBean developer);	 
	  
	  public void copyRow(TaskAssignBean developer);

	  
	  public void deletetask(int id);
	  
	  List<AddDeveloper> getAllName(AddDeveloper developer);
	  Map<String,String> getAllNameBYCode();
	  
}
