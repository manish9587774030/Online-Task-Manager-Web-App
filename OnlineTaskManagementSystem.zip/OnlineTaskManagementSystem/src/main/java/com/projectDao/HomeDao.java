package com.projectDao;

import java.util.List;
import java.util.Map;

import com.ProjectBean.ShowTaskAssign;

public interface HomeDao {
	
	
	List<ShowTaskAssign>viewhome();
	List<ShowTaskAssign>searchtask(ShowTaskAssign show);
	
	List<ShowTaskAssign>CompletedTask();
   
	List<ShowTaskAssign>PendingTask();
	

	
	public Map<String, String> getAllTaskCom();

}
