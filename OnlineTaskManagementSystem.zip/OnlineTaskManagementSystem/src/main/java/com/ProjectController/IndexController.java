package com.ProjectController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.projectDao.AdminDaoImpl;

@Controller
public class IndexController {

	@RequestMapping("/")
	public String index() {
		return "index";

	}

	@RequestMapping(value = "/AdminLogin", method = RequestMethod.POST)
	public String login(HttpServletRequest request, HttpServletResponse response, ModelMap map) {

		String username = request.getParameter("username");
		String password = request.getParameter("password");
		if (AdminDaoImpl.authenticate(username, password)) {
			HttpSession session = request.getSession();
			session.setAttribute("username", username);
			return "redirect:homes";

		} else {
			map.addAttribute("error", "plzentercorrectusernameandpassword");
			return "/index";
		}

	}

	@RequestMapping("/logout")
	public String logout(HttpServletRequest request, HttpServletResponse response) {

		HttpSession session = request.getSession();

		{

			session.removeAttribute("username");

			session.invalidate();
			

		}
		return "index";

	}

}
