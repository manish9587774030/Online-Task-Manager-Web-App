package com.ProjectController;

import java.util.List;
import java.util.Map;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.ProjectBean.ShowTaskAssign;

import com.projectDao.HomeDaoImpl;

@Controller
public class HomeController {

	@Autowired
	HomeDaoImpl showtaskhome;

	@RequestMapping(value = "/homes", method = RequestMethod.GET)

	public ModelAndView showtask(ModelAndView model,ShowTaskAssign assign) {
		List<ShowTaskAssign> list = showtaskhome.viewhome();
		model.addObject("tasklist", list); 
  
        List<ShowTaskAssign> list2=showtaskhome.CompletedTask();
        List<ShowTaskAssign>list3=showtaskhome.PendingTask();
         model.addObject("Completed",list2);
		 model.addObject("pending",list3);
		
		
		 
		Map<String,String> maps=showtaskhome.getAllTaskCom();
		model.addObject("getalltask", maps);
		System.out.println(maps);
		 
		
		
		model.setViewName("home");
		
		return model;
		

	}

	
}
