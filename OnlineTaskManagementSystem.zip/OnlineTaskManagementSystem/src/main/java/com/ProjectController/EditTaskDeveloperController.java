package com.ProjectController;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.ProjectBean.ShowTaskAssign;
import com.ProjectBean.TaskAssignBean;
import com.projectDao.DeveloperSubmitTaskImpl;

@Controller
public class EditTaskDeveloperController {

	@Autowired
	DeveloperSubmitTaskImpl showtask;

	@RequestMapping(value = "/editshowtaskdeveloper", method = RequestMethod.GET)
	public ModelAndView editdeveloper(HttpServletRequest request,
			@ModelAttribute("taskassignbean") TaskAssignBean task) {
		System.out.println("get data...........................");
		int id = Integer.parseInt(request.getParameter("id"));
		System.out.println("id" + id);

		task = showtask.gettask(id);
		System.out.println(task);

		ModelAndView model = new ModelAndView("showtaskdeveloperform");
		model.addObject("task", task);

		return model;
	}

	@RequestMapping(value = "/saveDeveloperTask", method = RequestMethod.GET)
	public ModelAndView saveTask(@ModelAttribute("showtaskassign") ShowTaskAssign bean) {
		System.out.println("save data........................");
       
        
		showtask.saveorupdate(bean);
		System.out.println("updated........................");
		return new ModelAndView("redirect:/viewupdatetask");
	}

}
