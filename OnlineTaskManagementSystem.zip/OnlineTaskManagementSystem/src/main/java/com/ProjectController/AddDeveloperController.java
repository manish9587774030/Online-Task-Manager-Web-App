package com.ProjectController;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.ProjectBean.AddDeveloper;
import com.projectDao.AddDeveloperImpl;

@Controller
public class AddDeveloperController {
	
	@Autowired
     AddDeveloperImpl dao;
	@RequestMapping(value = "/adddeveloper", method = RequestMethod.GET)
	public ModelAndView listDeveloper(ModelAndView model, ModelMap map) throws IOException {
		List<AddDeveloper> listdeveloper = dao.getAllDeveloper();

	
		model.addObject("developer", listdeveloper);

		model.setViewName("adddeveloper");


		return model;
	}
	

	@RequestMapping(value = "/savedeveloper", method = RequestMethod.POST)
	public String savedatafordeveloper(@ModelAttribute("adddeveloper")AddDeveloper developer,ModelMap map,Model m,HttpServletRequest request,ModelAndView model) {
		
		try
		{
			if(developer!=null )
			{
				developer.setActive_YN('Y');
				System.out.println("save dev......");
			dao.save(developer);
			System.out.println("not save dev....");
			HttpSession session=request.getSession();
		session.setAttribute("success" , "successfully Saved");
		

		
			return "redirect:/adddeveloper";
			
			}
		}
		catch(Exception e)
		{
		 if(developer.getUsercode().equals("usercode"))
			{
			System.out.println(e.getMessage());
			HttpSession session=request.getSession();
			session.setAttribute("unsuccess","unsuccessfully Saved data plz try diff usercode...");		
			
			return "redirect:/adddeveloper";
			}
		}
		return "redirect:/adddeveloper";
		
		 
	}


}
