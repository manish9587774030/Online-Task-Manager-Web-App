package com.ProjectController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.ProjectBean.AddDeveloper;
import com.ProjectBean.TaskAssignBean;
import com.projectDao.TaskAssignImpl;

@Controller
public class TaskAsignController {

	@Autowired
	TaskAssignImpl daotask;

	/*
	 * @RequestMapping(value = "/taskasign", method = RequestMethod.GET) public void
	 * Task(@ModelAttribute(value = "/adddeveloper") AddDeveloper developer,
	 * HttpServletRequest request) {
	 * 
	 * List<AddDeveloper> listCatagory = daotask.getAllName(developer);
	 * 
	 * request.setAttribute("listCategory", listCatagory);
	 * 
	 * }
	 */
	@RequestMapping(value = "/taskasign", method = RequestMethod.GET)
	public ModelAndView showtask(ModelAndView model,@ModelAttribute(value = "/adddeveloper") AddDeveloper developer, HttpServletRequest request) {
		try {
			List<AddDeveloper> listCatagory = daotask.getAllName(developer);
			
			request.setAttribute("listCategory", listCatagory);

			List<TaskAssignBean> list = daotask.getAllTask();

		
			model.addObject("tasklist", list);
			
			Map<String, String> maps=daotask.getAllNameBYCode();
			model.addObject("getallnamebycode", maps);
			

			model.setViewName("taskasign");

			return model;
		} catch (Exception e) {
			System.out.println(e);

		}
		return model;
	}
	

	@RequestMapping(value = "/savedata", method = RequestMethod.POST)
	public String savedatafortask(@ModelAttribute(value = "taskassignbean") TaskAssignBean bean,
			HttpServletRequest request) {

		
		try {
			if (bean != null) {
				bean.setACTIVE_YN('Y');
				bean.setid(4);
				System.out.println("taskAssign.............");
				
				daotask.saveEmployeeByPreparedStatement(bean);
				HttpSession session = request.getSession();
				session.setAttribute("taskassign", " TaskAssign successfully Saved");

				System.out.println("taskAssign");
				return "redirect:/taskasign";
			}
		}

		catch (Exception e) {
			System.out.println(e);
			
			
		}
		return "redirect:/taskasign";
	}

}
