package com.ProjectController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.projectDao.DeveloperLoginImpl;

@Controller
public class DeveloperLoginController {
	
	@RequestMapping(value = "/developerLogin", method = RequestMethod.GET)
	public String index() {
		return "developerlogin";
	}

	@RequestMapping(value = "/DeveloperLogin", method = RequestMethod.POST)
	public String login(HttpServletRequest request, HttpServletResponse response, ModelMap map) {

		String usercode= request.getParameter("usercode");
		String password = request.getParameter("password");
		if (DeveloperLoginImpl.authenticate(usercode, password)) {
			HttpSession session = request.getSession();
			session.setAttribute("usercode", usercode);
			return "redirect:homed";

		} else {
			map.addAttribute("error", "plzentercorrectusercodeandpassword");
			return "developerlogin";
		}

	}
       
	
	@RequestMapping("/logoutd")
	public String logout(HttpServletRequest request, HttpServletResponse response) {

		HttpSession session = request.getSession();

		{

			session.removeAttribute("usercode");

			session.invalidate();
			

		}
		return "developerlogin";

	}
	
	@RequestMapping(value="/homed",method = RequestMethod.GET)
     public String homed()
     {
    	 return "homedeveloper";
     }
	
}

