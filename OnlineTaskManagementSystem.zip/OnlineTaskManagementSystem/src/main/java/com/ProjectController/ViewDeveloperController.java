package com.ProjectController;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.ProjectBean.AddDeveloper;
import com.projectDao.AddDeveloperImpl;

@Controller
public class ViewDeveloperController {

	@Autowired
	AddDeveloperImpl dao;

	@RequestMapping(value = "/viewDeveloper")
	public ModelAndView listDeveloper(ModelAndView model, ModelMap map) throws IOException {
		List<AddDeveloper> listdeveloper = dao.getAllDeveloper();
        System.out.println(listdeveloper);
	
		model.addObject("developer", listdeveloper);

		model.setViewName("viewdeveloper");


		return model;
	}
	
	@RequestMapping(value = "/deletedeveloper", method = RequestMethod.GET)
	public ModelAndView deletedeveloper(HttpServletRequest request) {
	    int id = Integer.parseInt(request.getParameter("id"));
	    String Active_YN=(request.getParameter("Active_YN"));
	    System.out.println("id is:"+id);
	    System.out.println("Active_YN:"+Active_YN);
	     dao.delete(id);
	    return new ModelAndView("redirect:/adddeveloper");
	}
	
	
	
	
	@RequestMapping(value = "/editdeveloper", method = RequestMethod.GET)
	public ModelAndView editdeveloper(HttpServletRequest request,@ModelAttribute("developer" )AddDeveloper developer) {
		System.out.println("get data...........................");
	    int id = Integer.parseInt(request.getParameter("id"));
	    System.out.println("id"+id);
	  
	   
	  
	    developer= dao.get(id);
	   
	    ModelAndView model = new ModelAndView("developerEditForm");
	    model.addObject("developer", developer);
	 
	    return model;
	}
	
	
	@RequestMapping(value = "/saveeditdeveloper", method = RequestMethod.GET)
	public ModelAndView savedeveloper(@ModelAttribute("developer") AddDeveloper bean ) {
		System.out.println("save data........................"); 
		dao.saveorupdate(bean);
	    return new ModelAndView("redirect:/adddeveloper");
	}


	
	
	

}
