package com.ProjectController;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.ProjectBean.ShowTaskAssign;

import com.projectDao.ShowTaskCompletedImpl;

@Controller
public class ShowTaskCompletedAdminController {

	@Autowired
	ShowTaskCompletedImpl showtaskcomp;

	@RequestMapping(value = "/showtaskcompleted", method = RequestMethod.GET)
	public ModelAndView showtask(ModelAndView model){
		
		
		
		List<ShowTaskAssign> list = showtaskcomp.getAllTaskCompletedList();
		model.addObject("tasklistcompleted", list);
		model.setViewName("showdevelopertaskcompleted");
		return model;

	}
	
	@RequestMapping(value = "/showpendingtask", method = RequestMethod.GET)
	public ModelAndView showPendingTask(ModelAndView model){
		
		
		
		List<ShowTaskAssign> list = showtaskcomp.getAllTaskPending();
		model.addObject("tasklistpending", list);
		model.setViewName("showdevelopertaskPending");
		return model;

	}
	
	
	@RequestMapping(value = "/showinprocesstask", method = RequestMethod.GET)
	public ModelAndView showInProcessTask(ModelAndView model){
		
		
		
		List<ShowTaskAssign> list = showtaskcomp.getAllTaskInProcessList();
		model.addObject("tasklistinprocess", list);
		model.setViewName("showdevelopertaskinprocess");
		return model;

	}
	
	
	@RequestMapping(value="/weeklystatusreport",method = RequestMethod.GET)
	public ModelAndView weeklystatusreport(ModelAndView model)
	{
		model.setViewName("showweeklytaskreport");
		return model;
	}
	
	
}
