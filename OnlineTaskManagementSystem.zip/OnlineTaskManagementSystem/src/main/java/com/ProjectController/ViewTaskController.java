package com.ProjectController;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.ProjectBean.AddDeveloper;
import com.ProjectBean.TaskAssignBean;
import com.projectDao.TaskAssignImpl;

@Controller
public class ViewTaskController {

	@Autowired
	TaskAssignImpl daotask;

	@RequestMapping(value = "/viewTask", method = RequestMethod.GET)
	public ModelAndView showtask(ModelAndView model) {
		try {

			List<TaskAssignBean> list = daotask.getAllTask();

			System.out.println(list.size());
			model.addObject("tasklist", list);

			model.setViewName("taskshowdeveloper");

			return model;
		} catch (Exception e) {
			System.out.println(e);

		}
		return model;
	}

	@RequestMapping(value = "/edittaskdeveloper", method = RequestMethod.GET)
	public ModelAndView editdeveloper(HttpServletRequest request,
			@ModelAttribute("taskassignbean") TaskAssignBean task ,@ModelAttribute("adddeveloper")AddDeveloper developer) {
		System.out.println("get data...........................");
		int id = Integer.parseInt(request.getParameter("id"));
		System.out.println("id" + id);

		task = daotask.get(id);
	List<AddDeveloper> listCatagory = daotask.getAllName(developer);
		
		request.setAttribute("listCategory", listCatagory);

		ModelAndView model = new ModelAndView("taskdeveloperform");
		model.addObject("task", task);

		return model;
	}

	@RequestMapping(value = "/saveTaskDeveloper", method = RequestMethod.GET)
	public ModelAndView saveTask(@ModelAttribute("taskassignbean") TaskAssignBean bean) {
		System.out.println("save data........................");
		daotask.saveOrUpdate(bean);
		return new ModelAndView("redirect:/taskasign");
	}

	@RequestMapping(value = "/copytaskdeveloper", method = RequestMethod.GET)
	public ModelAndView copytask(@ModelAttribute("taskassignbean") TaskAssignBean bean) {
		System.out.println("copytask.................");
		daotask.copyRow(bean);
		return new ModelAndView("redirect:/taskasign");
	}

	@RequestMapping(value = "/deletetaskdeveloper", method = RequestMethod.GET)
	public ModelAndView deletetask(HttpServletRequest request) {
		int id = Integer.parseInt(request.getParameter("id"));
		System.out.println("id is:" + id);
		daotask.deletetask(id);
		return new ModelAndView("redirect:/taskasign");
	}

}
