package com.ProjectController;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.ProjectBean.ShowTaskAssign;
import com.projectDao.ShowTaskCompletedImpl;

@Controller
public class ViewUpdateDeveloperController {

	@Autowired
	ShowTaskCompletedImpl showtaskcomp;

	@RequestMapping(value = "/viewupdatetask", method = RequestMethod.GET)
	public ModelAndView showtaskdeveloper(ModelAndView model) {
		List<ShowTaskAssign> list = showtaskcomp.getAllTaskCompleted();
		model.addObject("tasklist", list);
		model.setViewName("showdevelopertaskcompletedview");
		return model;
        
	}
     
}
